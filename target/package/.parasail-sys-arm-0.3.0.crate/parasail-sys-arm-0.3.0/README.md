# parasail-sys

[![Build Status](https://img.shields.io/travis/dikaiosune/parasail-sys/master.svg?style=flat-square)](https://travis-ci.org/dikaiosune/parasail-sys) [![crates.io](https://img.shields.io/crates/v/parasail-sys.svg?style=flat-square)](https://crates.io/crates/parasail-sys/) [![API Docs](https://img.shields.io/badge/API-docs-blue.svg?style=flat-square)](https://dikaiosune.github.io/parasail-sys) [![License](https://img.shields.io/badge/license-MIT-lightgray.svg?style=flat-square)](https://github.com/dikaiosune/parasail-sys/blob/master/LICENSE)

This crates is unsafe Rust bindings for [parasail](https://github.com/jeffdaily/parasail). For the safe bindings, please see [parasailors](https://github.com/dikaiosune/parasailors).
