/**
 * @file
 *
 * @author jeffrey.daily@gmail.com
 *
 * Copyright (c) 2015 Battelle Memorial Institute.
 */
extern int parasail_ssw_dummy(void);

int parasail_ssw_dummy()
{
    return 0;
}

